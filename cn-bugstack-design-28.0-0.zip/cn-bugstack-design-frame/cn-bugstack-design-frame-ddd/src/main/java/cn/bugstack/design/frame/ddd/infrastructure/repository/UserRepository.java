package cn.bugstack.design.frame.ddd.infrastructure.repository;

import cn.bugstack.design.frame.ddd.domain.model.aggregates.UserInfoCollect;
import cn.bugstack.design.frame.ddd.domain.model.req.UserReq;
import cn.bugstack.design.frame.ddd.domain.repostory.IUserRepository;
import cn.bugstack.design.frame.ddd.infrastructure.repository.mysql.UserDBRepository;
import cn.bugstack.design.frame.ddd.infrastructure.repository.redis.UserRedisRepository;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;

@Repository("userRepository")
public class UserRepository implements IUserRepository {

    @Resource
    private UserDBRepository userDBRepository;
    @Resource
    private UserRedisRepository userRedisRepository;

    @Override
    public UserInfoCollect queryUserInfoList(UserReq req) {
        UserInfoCollect userInfoCollect = userRedisRepository.queryUserInfoList(req);
        if (null != userInfoCollect) return userInfoCollect;
        return userDBRepository.queryUserInfoList(req);
    }

}
