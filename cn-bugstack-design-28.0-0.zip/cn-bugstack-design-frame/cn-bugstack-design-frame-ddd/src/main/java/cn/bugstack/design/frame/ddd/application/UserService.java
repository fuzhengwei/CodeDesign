package cn.bugstack.design.frame.ddd.application;


import cn.bugstack.design.frame.ddd.domain.model.aggregates.UserInfoCollect;
import cn.bugstack.design.frame.ddd.domain.model.req.UserReq;

public interface UserService {

    UserInfoCollect queryUserInfoList(UserReq req);

}
