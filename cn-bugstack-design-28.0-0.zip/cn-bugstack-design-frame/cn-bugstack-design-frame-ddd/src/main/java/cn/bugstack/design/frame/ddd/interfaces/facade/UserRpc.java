package cn.bugstack.design.frame.ddd.interfaces.facade;

import cn.bugstack.design.frame.ddd.application.UserService;
import cn.bugstack.design.frame.ddd.domain.model.aggregates.UserInfoCollect;
import cn.bugstack.design.frame.ddd.interfaces.assembler.UserAssembler;
import cn.bugstack.design.frame.rpc.IUserRpc;
import cn.bugstack.design.frame.rpc.req.UserReq;
import cn.bugstack.design.frame.rpc.res.UserRes;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service("userRpc")
public class UserRpc implements IUserRpc {

    @Resource
    private UserService userService;

    @Override
    public UserRes queryUserInfoList(UserReq req) {
        UserInfoCollect userInfoCollect = userService.queryUserInfoList(UserAssembler.buildUserReq(req));
        return UserAssembler.buildUserInfoCollect(userInfoCollect);
    }

}
