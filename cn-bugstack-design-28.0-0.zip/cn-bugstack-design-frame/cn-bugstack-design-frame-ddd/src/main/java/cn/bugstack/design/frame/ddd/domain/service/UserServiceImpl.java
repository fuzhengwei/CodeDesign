package cn.bugstack.design.frame.ddd.domain.service;

import cn.bugstack.design.frame.ddd.application.UserService;
import cn.bugstack.design.frame.ddd.domain.model.aggregates.UserInfoCollect;
import cn.bugstack.design.frame.ddd.domain.model.req.UserReq;
import cn.bugstack.design.frame.ddd.domain.repostory.IUserRepository;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service("userService")
public class UserServiceImpl implements UserService {

    @Resource(name = "userRepository")
    private IUserRepository userRepository;

    @Override
    public UserInfoCollect queryUserInfoList(UserReq req) {
        return userRepository.queryUserInfoList(req);
    }

}
