package cn.bugstack.design.frame.ddd.interfaces.assembler;

import cn.bugstack.design.frame.ddd.domain.model.aggregates.UserInfoCollect;
import cn.bugstack.design.frame.ddd.domain.model.req.UserReq;
import cn.bugstack.design.frame.ddd.domain.model.vo.UserInfo;
import cn.bugstack.design.frame.parent.common.domain.Result;
import cn.bugstack.design.frame.rpc.dto.UserDto;
import cn.bugstack.design.frame.rpc.res.UserRes;

import java.util.ArrayList;
import java.util.List;

public class UserAssembler {

    public static UserReq buildUserReq(cn.bugstack.design.frame.rpc.req.UserReq req) {
        cn.bugstack.design.frame.ddd.domain.model.req.UserReq userReq = new UserReq();
        userReq.setName(req.getName());
        userReq.setStatus(req.getStatus());
        userReq.setPageStart(req.getPageStart());
        userReq.setPageEnd(req.getPageEnd());
        return userReq;
    }

    public static UserRes buildUserInfoCollect(UserInfoCollect userInfoCollect) {
        List<UserDto> dtoList = new ArrayList<>();
        List<UserInfo> userInfoList = userInfoCollect.getUserInfoList();
        for (UserInfo userInfo : userInfoList) {
            UserDto userDto = new UserDto();
            userDto.setName(userInfo.getName());
            userDto.setStatus(userInfo.getStatus());
            dtoList.add(userDto);
        }
        return new UserRes(Result.buildSuccessResult(), userInfoCollect.getCount(), dtoList);
    }

}
