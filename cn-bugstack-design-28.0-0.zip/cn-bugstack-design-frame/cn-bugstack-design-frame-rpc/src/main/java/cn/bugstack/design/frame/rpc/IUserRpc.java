package cn.bugstack.design.frame.rpc;

import cn.bugstack.design.frame.rpc.req.UserReq;
import cn.bugstack.design.frame.rpc.res.UserRes;

public interface IUserRpc {

    UserRes queryUserInfoList(UserReq req);

}
