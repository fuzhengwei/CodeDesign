package cn.bugstack.design.frame.ddd.domain.model.req;

import cn.bugstack.design.frame.parent.common.domain.PageRequest;

public class UserReq extends PageRequest {

    private String name;
    private Integer status;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}
