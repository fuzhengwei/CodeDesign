package cn.bugstack.design.frame.ddd.infrastructure.dao;

import cn.bugstack.design.frame.ddd.domain.model.req.UserReq;
import cn.bugstack.design.frame.ddd.infrastructure.po.User;

import java.util.List;

public interface IUserDao {

    List<User> queryUserInfoList(UserReq req);

    Long queryUserInfoCount(UserReq req);

}
