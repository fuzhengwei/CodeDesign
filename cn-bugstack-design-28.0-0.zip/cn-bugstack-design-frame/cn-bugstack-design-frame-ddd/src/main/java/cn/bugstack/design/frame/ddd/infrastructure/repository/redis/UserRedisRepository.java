package cn.bugstack.design.frame.ddd.infrastructure.repository.redis;

import cn.bugstack.design.frame.ddd.domain.model.aggregates.UserInfoCollect;
import cn.bugstack.design.frame.ddd.domain.model.req.UserReq;
import cn.bugstack.design.frame.ddd.domain.repostory.IUserRepository;
import cn.bugstack.design.frame.ddd.infrastructure.util.Redis;
import com.alibaba.fastjson.JSON;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;

@Repository("userRedisRepository")
public class UserRedisRepository implements IUserRepository {

    @Resource
    private Redis redis;

    @Override
    public UserInfoCollect queryUserInfoList(UserReq req) {
        if (StringUtils.isBlank(req.getName())) return null;
        Object obj = redis.get(req.getName());
        if (null == obj) return null;
        return JSON.parseObject(obj.toString(), UserInfoCollect.class);
    }

}
